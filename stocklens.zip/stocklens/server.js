const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/analyze", async (req, res) => {
  const { ticker } = req.body;
  if (!ticker) return res.status(400).json({ error: "Mangler ticker" });

  const prompt = `Analyser aktien ${ticker}. Svar KUN med råt JSON (ingen markdown):
{"ticker":"${ticker}","companyName":"Navn","overallScore":70,"rating":"HOLD","verdict":"2 sætninger om aktien.","pe":"24x","peNote":"Under snit","growth":"+12%","growthNote":"God vækst","margin":"18%","marginNote":"Stærk","debtEq":"0.4","debtEqNote":"OK","fundScore":75,"fundText":"2 sætninger om fundamentals.","growthScore":68,"growthText":"2 sætninger om vækst.","riskLevel":"MODERAT","riskText":"2 sætninger om risici.","valScore":60,"valText":"2 sætninger om værdi.","pros":["Pro 1","Pro 2","Pro 3"],"cons":["Con 1","Con 2","Con 3"],"dims":[{"n":"Finansiel styrke","s":78},{"n":"Vækstpotentiale","s":65},{"n":"Ledelse","s":80},{"n":"Konkurrence","s":72},{"n":"Aktionærværdi","s":60}]}
Rating: STÆRK KØB/KØB/HOLD/SÆLG/STÆRKT SÆLG. Scores 0-100.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 2000,
        messages: [{ role: "user", content: prompt }]
      })
    });

    const data = await response.json();
    if (data.error) return res.status(500).json({ error: data.error.message });

    const text = (data.content || []).map(b => b.type === "text" ? b.text : "").join("");
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) return res.status(500).json({ error: "Intet JSON i svaret" });

    res.json(JSON.parse(match[0]));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("*", (_, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`StockLens kører på port ${PORT}`));
